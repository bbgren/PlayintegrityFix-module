ui_print "nigga tock"
ui print "ExabyteMadness goes brrrrrrr"
ui print "Test..."